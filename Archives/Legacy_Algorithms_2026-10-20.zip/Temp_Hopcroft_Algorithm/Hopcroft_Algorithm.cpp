// Given a bipartite graph, find a minimum vertex cover and print the chosen vertices.
//
// Input:
// n m e
// e lines: u v
// u in [1..n] on the left side
// v in [1..m] on the right side
//
// Output:
// minimum vertex cover size
// then each chosen vertex, prefixed by its side: L or R

// The Messenger of Allah (Peace and blessings be upon him) said: "Whoever is humble for the sake of Allah, Allah will raise him".

#include <bits/stdc++.h>

using namespace std;

#define endl '\n'
#define ll long long

void Solve() {
  int n, m, e;
  cin >> n >> m >> e;

  // adj[u] = all right-side vertices connected to left vertex u
  vector<vector<int>> adj(n + 1);
  for (int i = 0; i < e; ++i) {
    int u, v;
    cin >> u >> v;
    adj[u].push_back(v);
  }

  // matchLeft[u] = the right vertex matched with left vertex u, or 0 if unmatched
  // matchRight[v] = the left vertex matched with right vertex v, or 0 if unmatched
  // dist[u] = BFS layer of left vertex u in Hopcroft-Karp
  vector<int> matchLeft(n + 1), matchRight(m + 1), dist(n + 1);

  // visLeft / visRight are used later in the alternating DFS
  // to build the minimum vertex cover after maximum matching is found
  vector<bool> visLeft(n + 1), visRight(m + 1);

  function<bool()> BFS = [&]() -> bool {
    queue<int> q;

    // Start BFS from all unmatched left vertices
    for (int i = 1; i <= n; ++i) {
      if (!matchLeft[i]) {
        dist[i] = 0;
        q.push(i);
      }

      else {
        dist[i] = -1;
      }
    }

    // found = whether there exists at least one augmenting path
    bool found = false;

    while (!q.empty()) {
      int u = q.front();
      q.pop();

      for (int v : adj[u]) {
        // If right vertex v is unmatched, then we found a possible augmenting path
        if (!matchRight[v]) {
          found = true;
        }

        // Otherwise, go to the matched left vertex of v
        // This builds the layered graph for Hopcroft-Karp
        else if (dist[matchRight[v]] == -1) {
          dist[matchRight[v]] = dist[u] + 1;
          q.push(matchRight[v]);
        }
      }
    }

    return found;
  };

  function<bool(int)> DFS = [&](int u) -> bool {
    for (int v : adj[u]) {
      // Either v is free, so we match u with v directly,
      // or we continue along the layered graph through the matched left vertex
      if (!matchRight[v] or (dist[matchRight[v]] == dist[u] + 1 and DFS(matchRight[v]))) {
        matchLeft[u] = v;
        matchRight[v] = u;
        return true;
      }
    }

    // Mark this left vertex as useless in current BFS phase
    dist[u] = -1;
    return false;
  };

  // Hopcroft-Karp:
  // repeatedly find all shortest augmenting paths with BFS,
  // then try to use them with DFS
  while (BFS()) {
    for (int i = 1; i <= n; ++i) {
      if (!matchLeft[i]) {
        DFS(i);
      }
    }
  }

  function<void(int)> DFS_Alternating = [&](int u) -> void {
    // We are currently at a left vertex, mark it visited
    visLeft[u] = true;

    for (int v : adj[u]) {
      // From a left vertex in the alternating graph,
      // we are allowed to go only through UNMATCHED edges
      if (matchLeft[u] == v) {
        continue;
      }

      if (!visRight[v]) {
        visRight[v] = true;

        // From a right vertex, if it is matched,
        // we continue only through its MATCHED edge back to the left side
        if (matchRight[v] and !visLeft[matchRight[v]]) {
          DFS_Alternating(matchRight[v]);
        }
      }
    }
  };

  // Start alternating DFS from every unmatched left vertex
  for (int i = 1; i <= n; ++i) {
    if (!matchLeft[i] and !visLeft[i]) {
      DFS_Alternating(i);
    }
  }

  // By König's theorem:
  // Minimum Vertex Cover =
  //   (all left vertices NOT visited)
  //   union
  //   (all right vertices visited)
  vector<pair<char, int>> ans;
  for (int i = 1; i <= n; ++i) {
    if (!visLeft[i]) {
      ans.push_back({'L', i});
    }
  }

  for (int i = 1; i <= m; ++i) {
    if (visRight[i]) {
      ans.push_back({'R', i});
    }
  }

  cout << ans.size() << endl;
  for (auto [side, vertex] : ans) {
    cout << side << ' ' << vertex << endl;
  }
}

int32_t main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);

  int t = 1;
  // cin >> t;
  for (int i = 1; i <= t; ++i) {
    Solve();
  }

  cerr << "Basel Al-Jabari." << endl;

  return 0;
}